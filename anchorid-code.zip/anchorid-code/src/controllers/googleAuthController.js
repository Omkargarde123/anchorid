const { OAuth2Client } = require('google-auth-library');
const userModel = require('../models/userModel');
const sessionService = require('../services/sessionService');

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Frontend sends the Google ID token after user signs in with Google popup/redirect
async function googleLogin(req, res) {
  const { idToken } = req.body;
  if (!idToken) return res.status(400).json({ error: 'idToken required' });

  try {
    // Verify the token actually came from Google and wasn't tampered with
    const ticket = await client.verifyIdToken({
      idToken,
      audience: process.env.GOOGLE_CLIENT_ID,
    });
    const payload = ticket.getPayload();
    const googleSub = payload.sub; // Google's permanent unique user ID
    const email = payload.email;

    // Check if this Google account is already linked to an AnchorID identity
    let user = await userModel.findUserByAuthMethod('google', googleSub);

    if (!user) {
      // First time we've seen this Google account — create a new identity
      user = await userModel.createUser(payload.name || email);
      await userModel.linkAuthMethod(user.id, 'google', googleSub);
    }

    const { token } = await sessionService.createSession(user.id, 'google', req.headers['user-agent']);

    res.json({ success: true, token, anchorId: user.anchor_id });
  } catch (err) {
    console.error('Google auth failed:', err.message);
    res.status(401).json({ error: 'Invalid Google token' });
  }
}

module.exports = { googleLogin };
