const userModel = require('../models/userModel');
const sessionService = require('../services/sessionService');

// Returns the logged-in user's identity info: linked auth methods + active sessions
async function getProfile(req, res) {
  const userId = req.userId; // set by authMiddleware

  const linkedMethods = await userModel.getLinkedMethods(userId);
  const activeSessions = await sessionService.getActiveSessions(userId);

  res.json({
    linkedMethods,
    activeSessions,
  });
}

// Lets a logged-in user link an ADDITIONAL auth method to their existing identity
// (e.g. they signed up with Google, now they want to also add email as backup)
async function linkAdditionalMethod(req, res) {
  const userId = req.userId;
  const { methodType, identifier } = req.body;

  const linked = await userModel.linkAuthMethod(userId, methodType, identifier);
  res.json({ success: true, linked });
}

module.exports = { getProfile, linkAdditionalMethod };
