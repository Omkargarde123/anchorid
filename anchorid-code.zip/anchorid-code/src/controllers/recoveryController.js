const crypto = require('crypto');
const pool = require('../config/db');
const userModel = require('../models/userModel');
const sessionService = require('../services/sessionService');
const { sendEmail } = require('../services/emailProvider');

const RECOVERY_EXPIRY_MINUTES = 30;

// STEP 1: User says "I lost access to my Google account, recover via email"
async function requestRecovery(req, res) {
  const { fallbackMethodType, fallbackIdentifier } = req.body;

  // Find the user via their fallback method (e.g. their backup email)
  const user = await userModel.findUserByAuthMethod(fallbackMethodType, fallbackIdentifier);
  if (!user) {
    return res.status(404).json({ error: 'No account found for this identifier' });
  }

  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const expiresAt = new Date(Date.now() + RECOVERY_EXPIRY_MINUTES * 60 * 1000);

  await pool.query(
    `INSERT INTO recovery_tokens (user_id, token_hash, expires_at) VALUES ($1, $2, $3)`,
    [user.id, tokenHash, expiresAt]
  );

  // Send the raw token via the fallback channel (e.g. email link)
  if (fallbackMethodType === 'email_otp') {
    await sendEmail(fallbackIdentifier, `Your AnchorID recovery link: /recover?token=${rawToken}`);
  }

  res.json({ success: true, message: 'Recovery instructions sent' });
}

// STEP 2: User clicks the recovery link/submits the token -> logs them back in
async function completeRecovery(req, res) {
  const { token } = req.body;
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');

  const result = await pool.query(
    `SELECT * FROM recovery_tokens WHERE token_hash = $1`,
    [tokenHash]
  );
  const record = result.rows[0];

  if (!record) return res.status(400).json({ error: 'Invalid recovery token' });
  if (record.used) return res.status(400).json({ error: 'Token already used' });
  if (new Date() > new Date(record.expires_at)) {
    return res.status(400).json({ error: 'Token expired' });
  }

  await pool.query('UPDATE recovery_tokens SET used = true WHERE id = $1', [record.id]);

  const { token: sessionToken } = await sessionService.createSession(
    record.user_id,
    'recovery',
    req.headers['user-agent']
  );

  res.json({ success: true, token: sessionToken });
}

module.exports = { requestRecovery, completeRecovery };
