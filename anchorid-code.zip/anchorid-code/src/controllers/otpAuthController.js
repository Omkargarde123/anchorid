const otpService = require('../services/otpService');
const userModel = require('../models/userModel');
const sessionService = require('../services/sessionService');
// Placeholder send functions — wire these to real providers (see notes below)
const { sendEmail } = require('../services/emailProvider');
const { sendSMS } = require('../services/smsProvider');

// STEP 1: User submits email or phone -> we generate + send an OTP
async function requestOTP(req, res) {
  const { identifier, methodType } = req.body; // methodType = 'email_otp' | 'phone_otp'

  if (!['email_otp', 'phone_otp'].includes(methodType)) {
    return res.status(400).json({ error: 'Invalid method type' });
  }

  const code = await otpService.generateOTP(identifier, methodType);

  if (methodType === 'email_otp') {
    await sendEmail(identifier, `Your AnchorID code is: ${code}`);
  } else {
    await sendSMS(identifier, `Your AnchorID code is: ${code}`);
  }

  res.json({ success: true, message: 'OTP sent' });
}

// STEP 2: User submits the code they received -> we verify and log them in
async function verifyOTPAndLogin(req, res) {
  const { identifier, methodType, code } = req.body;

  const verification = await otpService.verifyOTP(identifier, methodType, code);
  if (!verification.success) {
    return res.status(400).json({ error: verification.reason });
  }

  // Check if this identifier is already linked to an existing identity
  let user = await userModel.findUserByAuthMethod(methodType, identifier);

  if (!user) {
    // No existing identity uses this email/phone — create a new one
    user = await userModel.createUser(identifier);
    await userModel.linkAuthMethod(user.id, methodType, identifier);
  }

  const { token } = await sessionService.createSession(user.id, methodType, req.headers['user-agent']);

  res.json({ success: true, token, anchorId: user.anchor_id });
}

module.exports = { requestOTP, verifyOTPAndLogin };
