// TODO: Replace with a real email service (Nodemailer + SMTP, SendGrid, AWS SES, etc.)
// For now this just logs to console so you can test the OTP flow locally.

async function sendEmail(toAddress, message) {
  console.log(`[EMAIL to ${toAddress}]: ${message}`);

  // Example using Nodemailer (uncomment and configure when ready):
  //
  // const nodemailer = require('nodemailer');
  // const transporter = nodemailer.createTransport({
  //   service: 'gmail',
  //   auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
  // });
  // await transporter.sendMail({
  //   from: process.env.EMAIL_USER,
  //   to: toAddress,
  //   subject: 'Your AnchorID Verification Code',
  //   text: message,
  // });

  return true;
}

module.exports = { sendEmail };
