const crypto = require('crypto');
const pool = require('../config/db');

const OTP_EXPIRY_MINUTES = 5;
const MAX_ATTEMPTS = 3;

// Generate a 6-digit OTP and store its HASH (never the raw code) in DB
async function generateOTP(identifier, methodType) {
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const codeHash = crypto.createHash('sha256').update(code).digest('hex');
  const expiresAt = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);

  await pool.query(
    `INSERT INTO otp_codes (identifier, method_type, code_hash, expires_at)
     VALUES ($1, $2, $3, $4)`,
    [identifier, methodType, codeHash, expiresAt]
  );

  // Return the raw code ONLY so the caller can send it via email/SMS.
  // It is never stored in plaintext.
  return code;
}

// Verify a submitted OTP against the latest stored hash for that identifier
async function verifyOTP(identifier, methodType, submittedCode) {
  const result = await pool.query(
    `SELECT * FROM otp_codes
     WHERE identifier = $1 AND method_type = $2
     ORDER BY created_at DESC LIMIT 1`,
    [identifier, methodType]
  );

  const record = result.rows[0];
  if (!record) return { success: false, reason: 'No OTP requested' };
  if (record.used) return { success: false, reason: 'OTP already used' };
  if (new Date() > new Date(record.expires_at)) {
    return { success: false, reason: 'OTP expired' };
  }
  if (record.attempts >= MAX_ATTEMPTS) {
    return { success: false, reason: 'Too many attempts' };
  }

  const submittedHash = crypto.createHash('sha256').update(submittedCode).digest('hex');

  if (submittedHash !== record.code_hash) {
    await pool.query('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1', [record.id]);
    return { success: false, reason: 'Incorrect OTP' };
  }

  await pool.query('UPDATE otp_codes SET used = true WHERE id = $1', [record.id]);
  return { success: true };
}

module.exports = { generateOTP, verifyOTP };
