// TODO: Replace with a real SMS service (Twilio, AWS SNS, MSG91 for India, etc.)
// For now this just logs to console so you can test the OTP flow locally.

async function sendSMS(toPhoneNumber, message) {
  console.log(`[SMS to ${toPhoneNumber}]: ${message}`);

  // Example using Twilio (uncomment and configure when ready):
  //
  // const twilio = require('twilio');
  // const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH_TOKEN);
  // await client.messages.create({
  //   body: message,
  //   from: process.env.TWILIO_PHONE_NUMBER,
  //   to: toPhoneNumber,
  // });

  return true;
}

module.exports = { sendSMS };
