const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const pool = require('../config/db');

const SESSION_EXPIRY_HOURS = 24;

// Creates both a JWT (for the client) and a DB session row (for tracking/revocation)
async function createSession(userId, authMethod, deviceInfo = 'unknown') {
  const token = jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: '24h' });
  const sessionToken = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + SESSION_EXPIRY_HOURS * 60 * 60 * 1000);

  await pool.query(
    `INSERT INTO sessions (user_id, session_token, auth_method, device_info, expires_at)
     VALUES ($1, $2, $3, $4, $5)`,
    [userId, sessionToken, authMethod, deviceInfo, expiresAt]
  );

  return { token, sessionToken, expiresAt };
}

// List all active sessions for a user (multi-session visibility)
async function getActiveSessions(userId) {
  const result = await pool.query(
    `SELECT id, auth_method, device_info, created_at, expires_at
     FROM sessions WHERE user_id = $1 AND expires_at > NOW()
     ORDER BY created_at DESC`,
    [userId]
  );
  return result.rows;
}

module.exports = { createSession, getActiveSessions };
