const pool = require('../config/db');

// Create a brand new permanent identity
async function createUser(displayName) {
  const result = await pool.query(
    'INSERT INTO users (display_name) VALUES ($1) RETURNING *',
    [displayName]
  );
  return result.rows[0];
}

// Find which user owns a given auth method (e.g. this email, this google id)
async function findUserByAuthMethod(methodType, identifier) {
  const result = await pool.query(
    `SELECT u.* FROM users u
     JOIN linked_auth_methods lam ON lam.user_id = u.id
     WHERE lam.method_type = $1 AND lam.identifier = $2`,
    [methodType, identifier]
  );
  return result.rows[0] || null;
}

// Link a new auth method to an existing user (or create one if new)
async function linkAuthMethod(userId, methodType, identifier, credentialHash = null) {
  const result = await pool.query(
    `INSERT INTO linked_auth_methods (user_id, method_type, identifier, credential_hash, is_verified)
     VALUES ($1, $2, $3, $4, true)
     RETURNING *`,
    [userId, methodType, identifier, credentialHash]
  );
  return result.rows[0];
}

// Get every auth method linked to a user — used for account recovery options
async function getLinkedMethods(userId) {
  const result = await pool.query(
    'SELECT method_type, identifier, is_verified FROM linked_auth_methods WHERE user_id = $1',
    [userId]
  );
  return result.rows;
}

module.exports = {
  createUser,
  findUserByAuthMethod,
  linkAuthMethod,
  getLinkedMethods,
};
