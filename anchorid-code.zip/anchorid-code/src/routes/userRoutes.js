const express = require('express');
const router = express.Router();

const userController = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');

// All routes below require a valid JWT (set by authMiddleware)
router.use(authMiddleware);

router.get('/profile', userController.getProfile);
router.post('/link-method', userController.linkAdditionalMethod);

module.exports = router;
