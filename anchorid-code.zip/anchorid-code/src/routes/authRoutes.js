const express = require('express');
const router = express.Router();

const googleAuthController = require('../controllers/googleAuthController');
const otpAuthController = require('../controllers/otpAuthController');
const recoveryController = require('../controllers/recoveryController');

router.post('/google', googleAuthController.googleLogin);

router.post('/otp/request', otpAuthController.requestOTP);
router.post('/otp/verify', otpAuthController.verifyOTPAndLogin);

router.post('/recovery/request', recoveryController.requestRecovery);
router.post('/recovery/complete', recoveryController.completeRecovery);

module.exports = router;
