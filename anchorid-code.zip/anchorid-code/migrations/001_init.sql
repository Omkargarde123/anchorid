-- AnchorID Database Schema
-- One permanent identity, multiple linked auth methods

-- Core identity table — this is the "permanent" anchor
CREATE TABLE users (
    id              SERIAL PRIMARY KEY,
    anchor_id       UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
    display_name    VARCHAR(100),
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW()
);

-- Each row = one auth method linked to a user
-- A single user can have multiple rows here (Google + Email + Phone)
CREATE TABLE linked_auth_methods (
    id              SERIAL PRIMARY KEY,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    method_type     VARCHAR(20) NOT NULL CHECK (method_type IN ('google', 'email_otp', 'phone_otp', 'native')),
    identifier      VARCHAR(255) NOT NULL,   -- email address, phone number, or google sub ID
    credential_hash VARCHAR(255),             -- only for 'native' (hashed password)
    is_verified     BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP DEFAULT NOW(),
    UNIQUE(method_type, identifier)
);

-- Active login sessions (multi-session support)
CREATE TABLE sessions (
    id              SERIAL PRIMARY KEY,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_token   VARCHAR(255) UNIQUE NOT NULL,
    auth_method     VARCHAR(20) NOT NULL,     -- which method was used to log in
    device_info     VARCHAR(255),
    expires_at      TIMESTAMP NOT NULL,
    created_at      TIMESTAMP DEFAULT NOW()
);

-- OTP codes (temporary, short-lived)
CREATE TABLE otp_codes (
    id              SERIAL PRIMARY KEY,
    identifier      VARCHAR(255) NOT NULL,   -- email or phone the OTP was sent to
    method_type     VARCHAR(20) NOT NULL CHECK (method_type IN ('email_otp', 'phone_otp')),
    code_hash       VARCHAR(255) NOT NULL,    -- never store OTP in plaintext
    attempts        INTEGER DEFAULT 0,
    expires_at      TIMESTAMP NOT NULL,
    created_at      TIMESTAMP DEFAULT NOW()
);

-- Account recovery tokens (when user loses access to one method)
CREATE TABLE recovery_tokens (
    id              SERIAL PRIMARY KEY,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash      VARCHAR(255) UNIQUE NOT NULL,
    used            BOOLEAN DEFAULT FALSE,
    expires_at      TIMESTAMP NOT NULL,
    created_at      TIMESTAMP DEFAULT NOW()
);

-- Indexes for fast lookups
CREATE INDEX idx_linked_auth_user_id ON linked_auth_methods(user_id);
CREATE INDEX idx_linked_auth_identifier ON linked_auth_methods(identifier);
CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_otp_identifier ON otp_codes(identifier);
